// Local-only configuration. Copy dist/supabase-config.example.js to this file
// and add the project's URL and publishable key. Never use a secret/service_role key.
window.RV_SUPABASE_CONFIG = window.RV_SUPABASE_CONFIG || {
  url: 'https://fumzsmhvysdberyjemds.supabase.co',
  publishableKey: 'sb_publishable_j-blu6Kr70s09xam30s3hA_Y-2YELsL'
};
