if(!window.RV_CLOUD_ACTIVE){
function loadFictionalTestCase(){
  if(state.customers.some(c=>c.testFixture==='alex-morgan-v2')){toast('The fictional Alex Morgan test case is already loaded.');return;}
  const c=state.customers.find(x=>x.name==='TEST — Alex Morgan & family')||{id:'test-alex-morgan-2026',name:'TEST — Alex Morgan & family'};
  Object.assign(c,{testFixture:'alex-morgan-v2',type:'Active case',stage:'Active relocation',owner:'Stephanie',source:'Newsletter',campaign:'TEST — October relocation newsletter (fictional)',email:'alex.morgan@example.com',phone:'+84 90 000 0101',origin:'Lyon, France',destination:'Ho Chi Minh City, Vietnam',next:'TEST ONLY — confirm work-permit submission and container departure',updated:'Fictional end-to-end test record'});
  const cid=c.id;calendarMonth='2026-10';
  c.tracks=[
    {name:'Discovery and needs assessment',status:'Completed',owner:'Stephanie',due:'2026-10-02',next:'TEST ONLY — scope confirmed',documents:['Fictional relocation brief']},
    {name:'Immigration and work permit',status:'In progress',owner:'Olivier',due:'2026-10-12',next:'TEST ONLY — verify the sample employer letter',documents:['Fictional passport checklist','Fictional CV','Fictional experience letter','Fictional health check']},
    {name:'Company setup',status:'Waiting',owner:'Olivier',due:'2026-10-15',next:'TEST ONLY — awaiting fictional client approval',documents:['Fictional company profile']},
    {name:'Home search and lease',status:'Completed',owner:'Morgane',due:'2026-10-05',next:'TEST ONLY — sample lease signed',documents:['Fictional lease checklist']},
    {name:'School search',status:'In progress',owner:'Morgane',due:'2026-10-14',next:'TEST ONLY — compare two sample school options',documents:['Fictional school preferences']},
    {name:'Household goods container move',status:'Waiting',owner:'Stephanie',due:'2026-10-20',next:'TEST ONLY — confirm sample port departure update',documents:['Fictional packing inventory','Fictional customs checklist'],reference:'TEST-BOOKING-ONLY-001',partner:'TEST — Sample Freight Partner',lastUpdate:'2026-10-07 · TEST ONLY — simulated booking confirmed; no carrier lookup'},
    {name:'Arrival and settling in',status:'To do',owner:'Morgane',due:'2026-10-22',next:'TEST ONLY — prepare the sample arrival-day checklist',documents:['Fictional arrival checklist']}
  ];
  c.notes=[
    {text:'TEST ONLY — fictional enquiry received through a sample newsletter.',at:'01 Oct 2026 · TEST SCENARIO',by:'TEST — Stephanie'},
    {text:'TEST ONLY — fictional discovery call completed; family needs home, school, immigration and shipping support.',at:'03 Oct 2026 · TEST SCENARIO',by:'TEST — Olivier'},
    {text:'TEST ONLY — sample quote reviewed; awaiting two fictional approvals.',at:'06 Oct 2026 · TEST SCENARIO',by:'TEST — Team'}
  ];
  if(!state.customers.includes(c))state.customers.unshift(c);

  const threadId='test-thread-alex-morgan-001';
  state.threads=state.threads.filter(t=>t.id!==threadId);
  state.messages=state.messages.filter(m=>m.conversationId!==threadId);
  state.threads.unshift({id:threadId,topic:'TEST — Arrival, immigration and container coordination',contact:'TEST — Alex Morgan',customer:cid,relevance:'Business-related',status:'Follow-up scheduled',owner:'Olivier',priority:'Urgent',nextAction:'TEST ONLY — send the sample document checklist and confirm the shipment milestone',due:'2026-10-09',created:'2026-10-01',testFixture:'alex-morgan-v2'});
  const msg=(id,channel,direction,date,time,summary,status,action)=>({id,conversationId:threadId,channel,direction,date,time,contact:'TEST — Alex Morgan',customer:cid,owner:'Olivier',urgency:'Urgent',status,relevance:'Business-related',nextActionType:'Task',due:'2026-10-09',promised:'TEST ONLY — response by 2026-10-09',summary:'TEST ONLY — '+summary,body:'TEST ONLY — fictional sample content. No real customer message.',action,sourceLink:'',testFixture:'alex-morgan-v2'});
  state.messages.push(
    msg('test-msg-alex-1','Website','Received','2026-10-01','09:10','Interested in moving from France to Ho Chi Minh City with family.','Recorded','Arrange fictional discovery call.'),
    msg('test-msg-alex-2','Gmail','Sent','2026-10-02','14:20','Sent a sample list of information needed for a relocation brief.','Recorded','Review fictional family requirements.'),
    msg('test-msg-alex-3','WhatsApp','Received','2026-10-04','10:35','Asked whether assistance with a work permit and housing is available.','Recorded','Confirm the sample service scope.'),
    msg('test-msg-alex-4','Zalo','Received','2026-10-06','16:05','Asked for an update on the sample school shortlist and lease options.','Recorded','Prepare two fictional options.'),
    msg('test-msg-alex-5','Gmail','Received','2026-10-07','11:40','Shared a fictional packing inventory and asked about shipping milestones.','Waiting','Request a sample partner milestone.'),
    msg('test-msg-alex-6','Phone','Received','2026-10-08','08:50','Confirmed a fictional follow-up is needed on the document checklist.','Needs reply','Send the sample checklist by 2026-10-09.')
  );

  const task=(id,title,owner,status,due,priority,kind,serviceTrack,blocker='')=>({id,title:'TEST ONLY — '+title,customer:cid,owner,status,due,priority,kind,serviceTrack,blocker,testFixture:'alex-morgan-v2',completedAt:status==='Completed'?'2026-10-02':'',conversationId:threadId});
  state.tasks=state.tasks.filter(t=>!String(t.testFixture||'').startsWith('alex-morgan-'));
  state.tasks.push(
    task('test-task-alex-1','Complete discovery and record family requirements','Stephanie','Completed','2026-10-02','Normal','Customer action','Discovery and needs assessment'),
    task('test-task-alex-2','Send sample document checklist','Olivier','To do','2026-10-07','High','Document request','Immigration and work permit','TEST ONLY — past due to demonstrate the attention queue'),
    task('test-task-alex-3','Review fictional work-permit documents','Olivier','In progress','2026-10-09','High','Customer action','Immigration and work permit'),
    task('test-task-alex-4','Confirm sample company setup approval','Stephanie','Waiting','2026-10-12','Normal','Customer action','Company setup','TEST ONLY — awaiting client approval'),
    task('test-task-alex-5','Compare sample school options','Gabrielle','To do','2026-10-09','Normal','Customer action','School search'),
    task('test-task-alex-6','Check sample container milestone with partner','Stephanie','Needs confirmation','2026-10-08','Urgent','Customer action','Household goods container move'),
    task('test-task-alex-7','Prepare fictional arrival-day checklist','Morgane','To do','2026-10-20','Normal','Internal task','Arrival and settling in'),
    task('test-task-alex-8','Follow up on sample quote approval','Matt Jourdan','To do','2026-10-10','Normal','Promise follow-up','Discovery and needs assessment')
  );

  state.followups=state.followups.filter(f=>!String(f.testFixture||'').startsWith('alex-morgan-'));
  state.followups.unshift(
    {id:'test-followup-alex-visa',type:'Visa renewal',title:'TEST ONLY — sample visa renewal reminder',customer:cid,date:'2027-08-10',owner:'Olivier',status:'Needs confirmation',amount:'',currency:'USD',source:'TEST ONLY — no real visa record',notes:'Fictional future reminder; verify dates in real customer records.',testFixture:'alex-morgan-v2'},
    {id:'test-followup-alex-lease',type:'Lease renewal',title:'TEST ONLY — sample lease renewal planning',customer:cid,date:'2027-09-25',owner:'Gabrielle',status:'To do',amount:'',currency:'USD',source:'TEST ONLY — no real lease record',notes:'Fictional future reminder.',testFixture:'alex-morgan-v2'},
    {id:'test-followup-alex-commission',type:'Commission collection',title:'TEST ONLY — sample partner commission follow-up',customer:cid,date:'2026-10-15',owner:'Stephanie',status:'Waiting',amount:450,currency:'USD',source:'TEST ONLY — fictional ledger line',notes:'Fictional amount; not a payable claim.',testFixture:'alex-morgan-v2'}
  );

  state.finance=state.finance.filter(f=>!String(f.testFixture||'').startsWith('alex-morgan-'));
  state.finance.unshift(
    {id:'test-fin-alex-quote',kind:'Quote',date:'2026-10-03',due:'',label:'TEST ONLY — fictional relocation services quote',customer:cid,amount:6800,currency:'USD',paid:'',status:'Needs confirmation',source:'TEST ONLY — no real quote',testFixture:'alex-morgan-v2'},
    {id:'test-fin-alex-invoice',kind:'Invoice',date:'2026-10-05',due:'2026-10-12',label:'TEST ONLY — fictional service invoice',customer:cid,amount:3400,currency:'USD',paid:1200,status:'Partially paid',source:'TEST ONLY — no real invoice or payment',testFixture:'alex-morgan-v2'},
    {id:'test-fin-alex-payment',kind:'Customer payment',date:'2026-10-06',due:'',label:'TEST ONLY — fictional deposit entry',customer:cid,amount:1200,currency:'USD',paid:1200,status:'Verified paid',source:'TEST ONLY — fictional transaction',testFixture:'alex-morgan-v2'},
    {id:'test-fin-alex-expense',kind:'Expense',date:'2026-10-07',due:'',label:'TEST ONLY — fictional shipping estimate',customer:cid,amount:950,currency:'USD',paid:'',status:'Needs confirmation',source:'TEST ONLY — unconfirmed estimate',testFixture:'alex-morgan-v2'}
  );

  state.campaigns=state.campaigns.filter(x=>!String(x.testFixture||'').startsWith('alex-morgan-'));
  state.campaigns.unshift({id:'test-campaign-alex-newsletter',name:'TEST — October relocation newsletter (fictional)',channel:'Newsletter',workflow:'Submitted for review',owner:'Morgane',reviewer:'Stephanie',reviewNotes:'',date:'2026-10-01',reach:750,opens:322,clicks:46,inquiries:2,unsubscribes:1,source:'TEST ONLY — invented example metrics',notes:'Fictional figures for testing layout and attribution only.',testFixture:'alex-morgan-v2'});
  c.campaign='TEST — October relocation newsletter (fictional)';
  save();log('Loaded fictional end-to-end test case: Alex Morgan',cid);render();toast('Fictional Alex Morgan test case loaded. All records are labeled TEST ONLY.');
}
document.addEventListener('click',e=>{if(e.target.closest('[data-action="load-test-case"]'))loadFictionalTestCase();});

// Each browser profile has separate localStorage. Seed the fictional walkthrough once
// on first use in that profile; keep the explicit button available for manual reloads.
if(typeof process==='undefined'&&!state.customers.some(c=>c.testFixture==='alex-morgan-v2'))loadFictionalTestCase();
}
