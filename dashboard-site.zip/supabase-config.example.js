// Copy this file to supabase-config.js and fill in your Supabase project values.
// The publishable key is intended for client-side use; never place a secret key here.
window.RV_SUPABASE_CONFIG = {
  url: 'https://YOUR_PROJECT_REF.supabase.co',
  publishableKey: 'sb_publishable_REPLACE_ME'
};
